<nav class="navbar navbar-default">
<div class="container">
<ul class="nav navbar-nav">
<li><a href="javascript:void(0);" id="listar_contato"><i
class="glyphicon glyphicon-th-list"></i> Listar</a></li>
<li><a href="javascript:void(0);" id="novo_contato"><i
class="glyphicon glyphicon-plus"></i> Novo</a></li>
</ul>
</div>
</nav>
<div id="carregando" style="display: none; text-align: center;">
<img src="./common/images/carregando.gif" />
</div>