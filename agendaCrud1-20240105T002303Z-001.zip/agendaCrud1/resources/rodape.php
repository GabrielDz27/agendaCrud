</div>
<script type="text/javascript" src="./lib/jquery/js/jquery-3.1.1.js"></script>
<script type="text/javascript" src="./lib/bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="./common/js/crud.js"></script>
</body>
</html>