<?php include("cabecalho.php"); ?>
<?php include("nav.php"); ?>
<?php include("conteudo.php"); ?>
<?php include("rodape.php"); ?>